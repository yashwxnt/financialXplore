var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var quizSchema = new Schema({
  courseId: { type: Schema.Types.ObjectId, ref: 'Course', required: true },  
  questions: [
    {
      questionText: { type: String, required: true },
      options: [{ type: String, required: true }],
      correctOptionIndex: { type: Number, required: true },
      coinsPerCorrectAnswer: { type: Number, default: 1 },
    }
  ],
  durationMinutes: { type: Number, default: 15 },
  no_of_questions: { type: Number, required: true },
  totalCoins: { type: Number, default: 10 },

});

var Quiz = mongoose.model('Quiz', quizSchema);
module.exports = Quiz;
