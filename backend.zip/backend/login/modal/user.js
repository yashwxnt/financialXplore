var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({
    userName: String,
    password: String,
    email: String,
    phone: String,
    registeredCourses: String,
    totalCoinsEarned: { type: Number, default: 0 },
    badges: String,
    role: { type: String, enum: ['user', 'admin'], default: 'user' } 
});

var User = mongoose.model('User', userSchema);
module.exports = User;
