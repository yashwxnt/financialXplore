const mongoose = require('mongoose');

const courseSchema = new mongoose.Schema({
  courseName: { type: String, required: true },
  courseDescription: { type: String, required: true },
  courseContent: { type: String, required: true },
  courseCreatedBy: { type: String, required: true },
  courseCreatedDate: { type: Date, default: Date.now },
  courseImage: { type: String, required: true },
  __v: { type: Number, select: false },
});

module.exports = mongoose.model('Course', courseSchema);