var express = require('express');
var router = express.Router();
var mongo = require('mongoose');

// Import the User model
const User = require('../modal/user'); 

// Import the Course model
const Course = require('../modal/courses'); 
const Quizz = require('../modal/Quizz');

router.post("/register", (req, res) => {
  User.findOne({ userName: req.body.userName })
    .select('_id userName password')
    .then(result => {
      if (result != null) {
        res.json({ message: "Username already exists in the database" });
      } else {
        var myUser = new User({
          userName: req.body.userName,
          password: req.body.password,
          email: req.body.email,
          phone: req.body.phone
        });
        myUser.save()
          .then(result => res.json({ message: "User registered successfully" }))
          .catch(err => console.log(err));
      }
    })
    .catch(err => console.log(err));
});

router.post("/login", (req, res) => {
  var uname = req.body.userName;
  var pwd = req.body.password;

  User.findOne({ userName: uname }).select('_id userName password role')
    .then((result) => {
      if (result == null) {
        res.status(404).json({ message: "User not found" });
      } else {
        if (result.password == pwd) {
          res.status(200).json({
            userId: result._id,
            userName: result.userName,
            role: result.role
          });
        } else {
          res.status(401).json({ message: "Wrong username or password" });
        }
      }
    })
    .catch(err => {
      console.error(err);
      res.status(500).json({ message: "Internal Server Error" });
    });
});


router.post('/enroll', async (req, res) => {
  try {
    const { userId, courseId } = req.body;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    user.enrolledCourses.push(courseId);
    await user.save();

    res.status(200).json({ message: 'Enrolled in the course successfully.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

router.post('/feedback', async (req, res) => {
  try {
    const { userId, courseId, feedback } = req.body;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    const course = await Course.findById(courseId);
    if (!course) {
      return res.status(404).json({ message: 'Course not found.' });
    }

    course.feedback.push({ userId, content: feedback });
    await course.save();

    res.status(200).json({ message: 'Feedback submitted successfully.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});
router.get('/performance/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    // Retrieve user's enrolled courses and quizzes
    const user = await User.findById(userId).populate('enrolledCourses', 'courseName').populate('quizzesTaken', 'courseName totalCoins');

    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    res.status(200).json({ user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

router.get('/getCurrentUser/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    res.status(200).json({ user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});
router.get('/getUserEnrolledCourses/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findById(userId).populate('enrolledCourses', 'name');

    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    res.status(200).json({ user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});


module.exports = router;