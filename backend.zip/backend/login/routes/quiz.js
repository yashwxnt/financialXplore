const express = require('express');
const router = express.Router();
const mongoose = require('mongoose'); 
const Quiz = require('../modal/Quizz');
const Course = require('../modal/courses'); 

// Create a quiz
router.post('/create_quiz', async (req, res) => {
  try {
    const { courseId, courseTopic, questions, durationMinutes, no_of_questions, totalCoins } = req.body;

    // Validate required fields
    if (!courseId || !courseTopic || !questions || !durationMinutes || !no_of_questions || !totalCoins) {
      return res.status(400).json({ message: 'Invalid request. Please provide all required fields.' });
    }

    
    const course = await Course.findById(courseId);
    if (!course) {
      return res.status(404).json({ message: 'Course not found.' });
    }

    
    if (!Array.isArray(questions) || questions.length === 0) {
      return res.status(400).json({ message: 'Invalid questions array. Please provide at least one question.' });
    }

    
    for (const question of questions) {
      if (!question.questionText || !question.options || !question.correctOptionIndex) {
        return res.status(400).json({ message: 'Invalid question format. Please provide all required fields for each question.' });
      }
    }

    const newQuiz = new Quiz({
      courseId, 
      courseTopic,
      questions,
      durationMinutes,
      no_of_questions,
      totalCoins,
    });

    await newQuiz.save();

    res.status(201).json({ message: 'Quiz created successfully.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});


// Retrieve quizzes for a specific course 
router.get('/:courseId', async (req, res) => {
  try {
    const { courseId, courseTopic } = req.params;

    // Check if the course exists
    const course = await Course.findById(courseId);
    if (!course) {
      return res.status(404).json({ message: 'Course not found.' });
    }

    // Retrieve quizzes for the specified course and topic
    const quizzes = await Quiz.find({ courseId, courseTopic });

    res.status(200).json({ quizzes });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});
router.get('/questions/:courseId/:topic', async (req, res) => {
  try {
    const { courseId, topic } = req.params;

    // Fetch questions based on the courseId and topic
    const questions = await Quiz.find({ courseId}).limit(10); // Adjust limit as needed

    res.status(200).json({ questions });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});
module.exports = router;
