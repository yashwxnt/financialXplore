const express = require('express');
const router = express.Router();
const multer = require('multer');
const pdfParse = require('pdf-parse');
const Course = require('../modal/courses');

// Setup multer for file upload
const storage = multer.memoryStorage();
const upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (file.fieldname === 'coursePdf' && file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('File type not supported. Please upload a PDF file.'), false);
    }
  },
});

router.post('/uploadpdf', upload.single('coursePdf'), async (req, res) => {
  try {
    // Check if file is attached
    if (!req.file) {
      return res.status(400).json({ message: 'No file attached.' });
    }

    const { courseName, courseDescription, courseCreatedBy, courseImage } = req.body;
    const coursePdfBuffer = req.file.buffer;

    const pdfData = await pdfParse(coursePdfBuffer);
    const courseContent = pdfData.text;

    const newCourse = new Course({
      courseName,
      courseDescription,
      courseContent,
      courseCreatedBy,
      courseImage,
    });

    await newCourse.save();

    res.status(201).json({ message: 'Course created successfully.' });
  } catch (error) {
    console.error(error);

    res.status(500).json({ message: 'Internal Server Error', error: error.message });
  }
});

module.exports = router;
